<header class="site-header">
    <div class="container">
        <div class="row">
                        
            <div class="col-lg-12 col-12 d-flex flex-wrap">
                <p class="d-flex me-4 mb-0">
                    <i class="bi-person custom-icon me-2"></i>
                    <strong class="text-dark">Welcome to Music Festival 2023</strong>
                </p>
            </div>

        </div>
    </div>
</header>